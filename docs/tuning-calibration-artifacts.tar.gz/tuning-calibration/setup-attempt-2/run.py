"""Bounded native calibration experiment; no parameter adoption or strength test.
Uses an explicit pre-registration, fixed cohorts, independent PGN replay and CPU ledger.
"""
import datetime, hashlib, json, os, pathlib, re, resource, signal, subprocess, time
import chess, chess.engine, chess.pgn

ROOT = pathlib.Path('/tmp/asura-method')
REPO = pathlib.Path('/home/tom/dev/personal/asura')
FAST = pathlib.Path('/home/tom/.cache/asura_spsa/fastchess/fastchess')
BIN = ROOT / 'probe'
MODEL = REPO / 'asura_atn1.nnue'
PROFILES = ('ll', 'lh', 'hl', 'hh')
SEED = 20261104
HARD_SECONDS = 1800


def digest(path):
    h = hashlib.sha256()
    with pathlib.Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def save(path, obj):
    path.write_text(json.dumps(obj, indent=2, allow_nan=False) + '\n')


def cpu():
    r = resource.getrusage(resource.RUSAGE_CHILDREN)
    return r.ru_utime + r.ru_stime


def run(cmd, logfile, seconds):
    begin = time.monotonic()
    before = cpu()
    with logfile.open('w') as log:
        p = subprocess.Popen(cmd, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        try:
            rc = p.wait(timeout=seconds)
        except BaseException:
            os.killpg(p.pid, signal.SIGTERM)
            try:
                p.wait(timeout=3)
            except subprocess.TimeoutExpired:
                os.killpg(p.pid, signal.SIGKILL)
                p.wait()
            raise
    result = {'command': cmd, 'returncode': rc, 'wall_seconds': time.monotonic() - begin,
              'child_cpu_seconds': cpu() - before, 'log_sha256': digest(logfile)}
    if rc:
        raise RuntimeError(result)
    return result


def replay(path, profile, openings):
    lookup = {' '.join(x['fen'].split()[:4]): x['id'] for x in openings}
    pairs = {}
    games = []
    with path.open() as stream:
        while (game := chess.pgn.read_game(stream)) is not None:
            if game.errors:
                raise ValueError(f'{path}: PGN parse errors {game.errors}')
            board = game.board()
            key = ' '.join(board.fen().split()[:4])
            if key not in lookup or not board.is_valid():
                raise ValueError('unexpected/invalid starting position')
            white = game.headers.get('White')
            black = game.headers.get('Black')
            if {white, black} != {profile, 'base'}:
                raise ValueError(f'wrong players: {white} vs {black}')
            candidate_white = white == profile
            nodes = 0
            for node in game.mainline():
                move = node.move
                if move not in board.legal_moves:
                    raise ValueError('illegal move')
                board.push(move)
                marker = re.search(r'(?:\[%nodes (\d+)\]|\bn=(\d+)\b)', node.comment)
                if marker is None:
                    raise ValueError(f'missing node count in {path}: {node.comment!r}')
                nodes += int(marker.group(1) or marker.group(2))
            result = game.headers.get('Result')
            outcome = board.outcome(claim_draw=True)
            if outcome is None or outcome.result() != result:
                raise ValueError(f'{path}: non-natural/inconsistent result {result}: {game.headers}')
            # Signed score of a single game. Pair average is in [-1,1].
            signed_white = {'1-0': 1, '0-1': -1, '1/2-1/2': 0}[result]
            signed_candidate = signed_white if candidate_white else -signed_white
            opening = lookup[key]
            game_row = {'opening': opening, 'candidate_white': candidate_white, 'signed_score': signed_candidate,
                        'result': result, 'termination': outcome.termination.name,
                        'plies': len(list(game.mainline_moves())), 'reported_nodes': nodes}
            games.append(game_row)
            pairs.setdefault(opening, []).append(game_row)
    if len(games) != 16 or set(pairs) != {x['id'] for x in openings}:
        raise ValueError(f'missing/extra games or openings: {len(games)}, {pairs.keys()}')
    observations = []
    for opening in openings:
        rows = pairs[opening['id']]
        if len(rows) != 2 or {g['candidate_white'] for g in rows} != {True, False}:
            raise ValueError('not a color-reversed pair')
        observations.append({'profile': profile, 'opening': opening['id'],
                             'signed_pair_score': sum(g['signed_score'] for g in rows) / 2})
    return {'pgn_sha256': digest(path), 'games': games, 'pairs': observations,
            'nodes': sum(g['reported_nodes'] for g in games)}


def matches(label, budget, openings, deadline):
    # Four separately indexed matches guarantee all candidates see the SAME book.
    active = []
    start = time.monotonic()
    before_cpu = cpu()
    try:
        for profile in PROFILES:
            directory = ROOT / f'{label}-{profile}'
            directory.mkdir()
            cmd = ['taskset', '-c', '12-23', str(FAST),
                   '-engine', f'cmd={BIN}', f'args=play {MODEL} {profile}', f'name={profile}',
                   '-engine', f'cmd={BIN}', f'args=play {MODEL} base', 'name=base',
                   '-each', 'proto=uci', 'option.Hash=16', 'option.Threads=1', f'nodes={budget}',
                   '-openings', f'file={ROOT / "openings.epd"}', 'format=epd', 'order=sequential',
                   '-srand', str(SEED), '-rounds', '8', '-games', '2', '-concurrency', '2',
                   '-pgnout', f'file={directory / "games.pgn"}', 'nodes=true', 'append=false',
                   '-log', f'file={directory / "engine.log"}', 'level=warn', 'append=false',
                   '-config', 'discard=true', f'outname={directory / "config.json"}',
                   '-autosaveinterval', '0', '-strict']
            save(directory / 'command.json', cmd)
            log = (directory / 'match.log').open('w')
            process = subprocess.Popen(cmd, cwd=directory, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
            active.append((profile, directory, process, log))
        save(ROOT / 'active.json', [{'cohort': label, 'profile': c, 'pid': p.pid} for c, d, p, l in active])
        while True:
            returncodes = [p.poll() for _, _, p, _ in active]
            if any(rc not in (None, 0) for rc in returncodes):
                raise RuntimeError(f'{label} child failed: {returncodes}')
            if all(rc is not None for rc in returncodes):
                break
            if time.monotonic() >= deadline:
                raise TimeoutError(f'{label}: experiment hard deadline')
            time.sleep(1)
        results = {}
        for profile, directory, process, log in active:
            log.close()
            results[profile] = replay(directory / 'games.pgn', profile, openings)
            save(directory / 'verified.json', results[profile])
        row = {'cohort': label, 'nodes_per_move': budget, 'wall_seconds': time.monotonic() - start,
               'child_cpu_seconds': cpu() - before_cpu, 'matches': results}
        save(ROOT / f'{label}-verified.json', row)
        print(json.dumps({'cohort': label, 'status': 'complete', 'wall_seconds': row['wall_seconds'],
                          'child_cpu_seconds': row['child_cpu_seconds']}), flush=True)
        return row
    finally:
        for _, _, p, log in active:
            if p.poll() is None:
                os.killpg(p.pid, signal.SIGTERM)
        for _, _, p, log in active:
            try:
                p.wait(timeout=3)
            except subprocess.TimeoutExpired:
                os.killpg(p.pid, signal.SIGKILL)
                p.wait()
            log.close()
        save(ROOT / 'active.json', [])


def main():
    start = time.monotonic()
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    deadline = start + HARD_SECONDS
    if (ROOT / 'preregister.json').exists():
        raise RuntimeError('Refuse to overwrite/retry the registered cohort')
    openings = json.loads(pathlib.Path('/tmp/asura-strength/openings.json').read_text())[:8]
    for o in openings:
        if not chess.Board(o['fen']).is_valid():
            raise ValueError('invalid opening')
    (ROOT / 'openings.epd').write_text(''.join(o['fen'] + '\n' for o in openings))
    # These early-opening fixtures exercise only the neutral-score branch.
    (ROOT / 'openings.fens').write_text(''.join('0\t' + o['fen'] + '\n' for o in openings))
    save(ROOT / 'openings.json', openings)
    profiles_text = subprocess.check_output([str(BIN), 'describe'], text=True)
    (ROOT / 'profiles.tsv').write_text(profiles_text)
    source_paths = subprocess.check_output(['git', '-C', str(REPO), 'ls-files', 'src', 'build', 'Cargo.toml', 'Cargo.lock', '.cargo'], text=True).splitlines()
    source_paths += ['tools/tuning_calibration_probe.rs']
    prereg = {
        'time_utc': started, 'commit': subprocess.check_output(['git','-C',str(REPO),'rev-parse','HEAD'],text=True).strip(),
        'purpose': 'Fidelity/predictor pilot, NOT an optimizer comparison or candidate promotion.',
        'pre_game_amendment': 'Setup attempt 1 failed before ANY match because the driver expected optional UCI pv output. Corrected to use play().move (bestmove); no engine/model/profile/opening/budget/analysis changes. Original registration, failure and 0.190199 child CPU seconds preserved in setup-attempt-1; no game discarded.',
        'model_sha256': digest(MODEL), 'binary_sha256': digest(BIN), 'runner_sha256': digest(__file__),
        'source_sha256': {p: digest(REPO / p) for p in source_paths}, 'fastchess_sha256': digest(FAST),
        'openings_sha256': digest(ROOT / 'openings.epd'), 'profiles': profiles_text.splitlines(),
        'opening_scope': 'First eight published frozen audit openings, reused without examining candidate outcomes. Not unseen engine-training data. Only early neutral positions; not a representative phase/style corpus.',
        'shared_historical_preparation': 'Earlier opening checks were 8 x approximately 500k reference nodes. Reused, not timed anew; not claimed free in any campaign comparison.',
        'budget': {'hard_wall_seconds': HARD_SECONDS, 'max_games': 128, 'game_concurrency': 8,
                   'threads_per_engine': 1, 'hash_mib_per_engine': 16, 'cpu_affinity': list(range(12,24)),
                   'cheap_nodes': 5000, 'target_nodes': 500000, 'scorecard_nodes': [500,1500,4500], 'label_nodes':6000},
        'adjudication': 'No score-based resign/draw/maxmoves. Natural checkmate/stalemate/repetition/rule-50/material endings only; any failure/incomplete pair invalidates cohort.',
        'stopping': 'Complete all predeclared games unless hard timeout or mechanical failure. No score-dependent early stop, replacement games, candidate reselection or adoption.',
        'analysis': {
            'unit': 'color-reversed opening pair; signed score = candidate total points in two games minus one',
            'calibration_openings': [o['id'] for o in openings[:4]],
            'heldout_openings': [o['id'] for o in openings[4:]],
            'predictors': ['native position utility(candidate)-utility(base)', '5000-node paired-game signed score'],
            'fit': 'One affine predictor per cheap source, OLS on first four opening families (16 records); clip game predictions to [-1,1]. No fitting or model choice on held-out families.',
            'measure': 'On other four families report centered-within-candidate residual sum of squares / outcome sum of squares; also mean-squared prediction error and candidate-mean ordering. All ties and zero variances explicit.',
            'optimistic_diagnostic': 'Also show best hindsight single linear slope on held-out centered vectors, labeled in-sample oracle NOT a deployable predictor or validated saving.',
            'uncertainty': 'Only 4 held-out opening families. Descriptive finite-cohort diagnostics, no robust population correlation/Elo inference and no significance-based promotion.',
            'compute': 'New preparation, all cheap and target games, failed work and analysis are charged. Cached build/historical opening-generation work is separately disclosed; no equal-compute SPSA claim.'
        }
    }
    save(ROOT / 'preregister.json', prereg)
    phases = {}
    # Check public UCI at actual NNUE/nodes: runtime-default and production-default
    # paths must produce identical moves, scores, depths and node counts.
    sanity_start = time.monotonic()
    sanity_cpu = cpu()
    rows = []
    controls = []
    try:
        for profile in ('frozen', 'base'):
            engine = chess.engine.SimpleEngine.popen_uci([str(BIN), 'play', str(MODEL), profile], timeout=20)
            controls.append(engine)
            engine.configure({'Hash':16, 'Threads':1})
        for opening in openings:
            results = []
            for engine in controls:
                played = engine.play(chess.Board(opening['fen']), chess.engine.Limit(nodes=50000),
                                     game=object(), info=chess.engine.INFO_ALL)
                result = played.info
                if played.move is None:
                    raise ValueError('default sanity returned no bestmove')
                results.append({'move':played.move.uci(), 'score':str(result['score'].white()),
                                'depth':result['depth'], 'nodes':result['nodes']})
            if results[0] != results[1]:
                raise ValueError(f'default path differs: {opening["id"]}: {results}')
            rows.append({'opening':opening['id'], 'both':results[0]})
    finally:
        for engine in controls:
            engine.quit()
    phases['default_path_sanity'] = {'rows':rows, 'wall_seconds':time.monotonic()-sanity_start, 'child_cpu_seconds':cpu()-sanity_cpu}
    phases['scorecard'] = run(['taskset','-c','12-23',str(BIN),'probe',str(MODEL),str(ROOT/'openings.fens')], ROOT/'scorecard.tsv', 200)
    save(ROOT / 'before-games.json', {'phases':phases, 'scorecard_sha256':digest(ROOT/'scorecard.tsv'),
                                    'preregister_sha256':digest(ROOT/'preregister.json')})
    print('Default-path sanity and pre-game native scorecard complete; starting fixed cohorts.', flush=True)
    phases['cheap'] = matches('cheap',5000,openings,deadline)
    phases['target'] = matches('target',500000,openings,deadline)
    save(ROOT / 'run-complete.json', {'status':'complete', 'wall_seconds':time.monotonic()-start,
                                    'child_cpu_seconds':cpu(), 'phases':phases,
                                    'model_unchanged':digest(MODEL)==prereg['model_sha256']})
    print('COMPLETE: all cohorts independently replayed; no settings adopted.', flush=True)


if __name__ == '__main__':
    try:
        main()
    except BaseException as exc:
        save(ROOT / 'run-failed.json', {'error':repr(exc),'time_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
                                      'child_cpu_seconds':cpu(), 'status':'failed; do not treat partial results as a completed cohort'})
        raise
