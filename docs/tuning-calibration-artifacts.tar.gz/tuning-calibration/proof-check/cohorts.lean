import audited_tuning
open AuditedTuning

def rat (q : Rat) : String := s!"{q.num}/{q.den}"
def emit (label : String) (n k : Nat) (y p : Vec n) : IO Unit := do
  let e := expect (estimator (k := k) y p)
  let v := randomVariance (estimator (k := k) y p)
  let o := randomVariance (ordinaryMean (k := k) y)
  let r := variance (residual y p) / (k : Rat)
  IO.println s!"CHECK\t{label}\t{k}\t{rat (avg y)}\t{rat e}\t{rat v}\t{rat o}\t{rat r}"

def main : IO Unit := do
  let y0 : Vec 4 := fun i => match i.val with | 0 => ((0 : Rat) / 1) | 1 => ((1 : Rat) / 2) | 2 => ((0 : Rat) / 1) | 3 => ((0 : Rat) / 1) | _ => 0
  let p0 : Vec 4 := fun i => match i.val with | 0 => ((-3 : Rat) / 32) | 1 => ((-3 : Rat) / 32) | 2 => ((-3 : Rat) / 32) | 3 => ((-3 : Rat) / 32) | _ => 0
  for k in [1, 2, 3] do emit "scorecard/ll" 4 k y0 p0
  let y1 : Vec 4 := fun i => match i.val with | 0 => ((0 : Rat) / 1) | 1 => ((0 : Rat) / 1) | 2 => ((-1 : Rat) / 2) | 3 => ((-1 : Rat) / 2) | _ => 0
  let p1 : Vec 4 := fun i => match i.val with | 0 => ((-3 : Rat) / 32) | 1 => ((-3 : Rat) / 32) | 2 => ((-3 : Rat) / 32) | 3 => ((-3 : Rat) / 32) | _ => 0
  for k in [1, 2, 3] do emit "scorecard/lh" 4 k y1 p1
  let y2 : Vec 4 := fun i => match i.val with | 0 => ((0 : Rat) / 1) | 1 => ((0 : Rat) / 1) | 2 => ((-1 : Rat) / 2) | 3 => ((0 : Rat) / 1) | _ => 0
  let p2 : Vec 4 := fun i => match i.val with | 0 => ((-3 : Rat) / 32) | 1 => ((-3 : Rat) / 32) | 2 => ((-3 : Rat) / 32) | 3 => ((-3 : Rat) / 32) | _ => 0
  for k in [1, 2, 3] do emit "scorecard/hl" 4 k y2 p2
  let y3 : Vec 4 := fun i => match i.val with | 0 => ((0 : Rat) / 1) | 1 => ((-1 : Rat) / 2) | 2 => ((0 : Rat) / 1) | 3 => ((1 : Rat) / 2) | _ => 0
  let p3 : Vec 4 := fun i => match i.val with | 0 => ((-3 : Rat) / 32) | 1 => ((-3 : Rat) / 32) | 2 => ((-3 : Rat) / 32) | 3 => ((-3 : Rat) / 32) | _ => 0
  for k in [1, 2, 3] do emit "scorecard/hh" 4 k y3 p3
  let y4 : Vec 4 := fun i => match i.val with | 0 => ((0 : Rat) / 1) | 1 => ((1 : Rat) / 2) | 2 => ((0 : Rat) / 1) | 3 => ((0 : Rat) / 1) | _ => 0
  let p4 : Vec 4 := fun i => match i.val with | 0 => ((-67 : Rat) / 734) | 1 => ((-48 : Rat) / 367) | 2 => ((-9 : Rat) / 734) | 3 => ((-9 : Rat) / 734) | _ => 0
  for k in [1, 2, 3] do emit "cheap_game/ll" 4 k y4 p4
  let y5 : Vec 4 := fun i => match i.val with | 0 => ((0 : Rat) / 1) | 1 => ((0 : Rat) / 1) | 2 => ((-1 : Rat) / 2) | 3 => ((-1 : Rat) / 2) | _ => 0
  let p5 : Vec 4 := fun i => match i.val with | 0 => ((-19 : Rat) / 367) | 1 => ((-9 : Rat) / 734) | 2 => ((-19 : Rat) / 367) | 3 => ((-67 : Rat) / 734) | _ => 0
  for k in [1, 2, 3] do emit "cheap_game/lh" 4 k y5 p5
  let y6 : Vec 4 := fun i => match i.val with | 0 => ((0 : Rat) / 1) | 1 => ((0 : Rat) / 1) | 2 => ((-1 : Rat) / 2) | 3 => ((0 : Rat) / 1) | _ => 0
  let p6 : Vec 4 := fun i => match i.val with | 0 => ((-125 : Rat) / 734) | 1 => ((-67 : Rat) / 734) | 2 => ((-19 : Rat) / 367) | 3 => ((-19 : Rat) / 367) | _ => 0
  for k in [1, 2, 3] do emit "cheap_game/hl" 4 k y6 p6
  let y7 : Vec 4 := fun i => match i.val with | 0 => ((0 : Rat) / 1) | 1 => ((-1 : Rat) / 2) | 2 => ((0 : Rat) / 1) | 3 => ((1 : Rat) / 2) | _ => 0
  let p7 : Vec 4 := fun i => match i.val with | 0 => ((-48 : Rat) / 367) | 1 => ((-67 : Rat) / 734) | 2 => ((-67 : Rat) / 734) | 3 => ((-9 : Rat) / 734) | _ => 0
  for k in [1, 2, 3] do emit "cheap_game/hh" 4 k y7 p7
