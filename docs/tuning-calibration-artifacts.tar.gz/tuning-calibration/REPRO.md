# Frozen calibration pilot artifacts

This is a completed **negative fidelity/predictor pilot**, not an adopted parameter
set, independent strength confirmation, or an equal-compute SPSA comparison.

Native code came from Asura `6221d252ccb1ee911cfdf3a477ae1b943e37d244` plus the
standalone driver in `source/tools/tuning_calibration_probe.rs`. The driver
compiles the actual tuner configuration/evaluator modules; it does not copy or
substitute the search or NNUE. `preregister.json` records source, model, binary,
book and runner hashes. Default production and runtime-enabled parameter paths
agreed on eight 50k-node UCI checks (move, score, depth and node count).

The published native checkpoint and parameter source were unchanged. Four
LMR-table-scale/singular-margin corners were tested against runtime-enabled
baseline settings, never installed. All 128 games completed. `run.py` independently
replayed every move using python-chess 1.11.2, checked natural terminal results,
and required a complete color-reversed pair for every candidate/opening/budget.

`run.py` is the exact registered original launcher. It retains the original
absolute machine paths; **do not launch it as-is into an existing artifact directory**.
Two pre-game setup failures are preserved with their exact original source hashes.
The first assumed optional UCI PV output; the second accidentally discarded the
Fastchess engine/book configuration. Both were fixed before any game was played;
no match result was discarded or used to change the protocol. Position scores
before and after the second setup attempt were identical.

## Recompute the analysis and finite-model checks

From the Asura repository, with ART pointing to this extracted directory:

```sh
python3 tools/analyze_tuning_calibration.py "$ART" --output /tmp/new-analysis.json
python3 tools/check_audited_tuning.py --analysis /tmp/new-analysis.json
```

Only Python's standard library is needed for the first command; the second also
requires installed Lean 4.35.0 (tested). Neither command downloads dependencies.
`analysis_cpu_seconds` and the proof-check wall time naturally vary. All rational
coefficients and cohort calculations should agree. The proof check enumerates
all ordered audit tuples for sample counts 1, 2, 3: 24 cohort/count records across
8 frozen predictor/candidate combinations. This checks arithmetic of the finite
probability model, not random sampling, chess execution, an adaptive optimizer or Elo.

`SHA256.json` covers every other archived file. The archive excludes executable
binaries, checkpoints, Lean build files and dependencies.

## Run the same native probes on this revision

```sh
cargo build --release --lib
rustc --edition 2024 -O -C target-cpu=native -C panic=abort \
  -C lto=fat -C codegen-units=1 tools/tuning_calibration_probe.rs \
  --extern asura=target/release/libasura.rlib \
  -L dependency=target/release/deps -o /tmp/tuning-calibration-probe
/tmp/tuning-calibration-probe describe
/tmp/tuning-calibration-probe probe "$PWD/asura_atn1.nnue" "$ART/openings.fens"
```

The driver has a fixed eight-position diagnostic scope. Its game mode is
`play MODEL PROFILE`, with profiles `base`, `ll`, `lh`, `hl`, `hh`, and the
production-default comparison `frozen`. The registered per-cohort Fastchess
commands are in `cheap-*/command.json` and `target-*/command.json`; substitute
absolute binary/model/book/output paths, use **new output directories**, and set
an external runtime limit. They use one thread, 16 MiB hash, 8 opening rounds,
2 swapped-color games per round, and no score-based or maximum-move adjudication.
The original controller allowed 1,800 seconds and eight simultaneous games.

For a new experiment, freeze a new protocol and budget before observing results.
Do not tune or select predictors on these held-out outcomes and then call the
same panel a new independent test. Earlier opening-generation costs, cached builds,
proof/development work and data preparation are not free: not all of those costs
were instrumented here. No total-campaign compute-saving claim is made.
